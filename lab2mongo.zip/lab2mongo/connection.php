<?php
require_once __DIR__ .'/vendor/autoload.php'; // подключаем автоподгрузчик классов Composer
$db = (new MongoDB\Client)->lab3var3;